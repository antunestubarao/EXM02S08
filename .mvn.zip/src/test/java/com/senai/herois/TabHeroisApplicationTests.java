package com.senai.herois;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TabHeroisApplicationTests {

	@Test
	void contextLoads() {
	}

}
